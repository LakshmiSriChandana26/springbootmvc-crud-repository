package com.nt.controller;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nt.model.Employee;
import com.nt.service.IEmployeeMgmtService;

@Controller
public class EmployeeController {
	@Autowired
	 private IEmployeeMgmtService empservice;
	
	@GetMapping("/")
	public String showHomePage() {
		return "home";
	}
	
	
	@GetMapping("/report")
	public String showEmployeeReport(Map<String, Object> map) {
	    Iterable<Employee> itEmps = empservice.getAllEmployees(); 
	    map.put("empsList", itEmps);
	    return "show_employee_report";
	}

	 @GetMapping("/emp_add") // Show the form
	    public String showFormForSaveEmployee(@ModelAttribute("emp") Employee emp) {
	        return "register_employee";
	    }
	

	    @PostMapping("/saveEmployee") // Handle form submission
	    public String saveEmployee(@ModelAttribute("emp") Employee emp, Model model) {
	        System.out.println("Saving Employee: " + emp);
	        String result = empservice.registerEmployee(emp);
	        model.addAttribute("message", result);
	        return "register_employee";
	    }
	   
	  
	    @GetMapping("/emp_edit")
	    public String showEditEmployeeFormPage(@RequestParam("no") int empno,@ModelAttribute("emp")Employee emp) {
	    	System.out.println(empno);
	        System.out.println("Employee Number: " + empno);
	        Employee emp1=empservice.getEmployeeByEno(empno);
	        BeanUtils.copyProperties(emp1, emp);
			return  "modify_employee";
	       
	    }

	    @GetMapping("/emp_delete")
	    public String deleteEmployee(RedirectAttributes attrs,@RequestParam int no) {
	        String msg=empservice.deleteEmployeeByEno(no);
	        attrs.addFlashAttribute("resultMsg", msg);
	        System.out.println("detalis deleted with id:"+no);
	        return "redirect";
	       // return "redirect:show_employee_report";
	    }
	    
	    @GetMapping("/insert_employee")
		public  String   showAddEmployeeForm(@ModelAttribute("emp") Employee emp) {
			   //return LNV
			return "add_employee";
		}
	    
	    
	   /* @GetMapping("/emp_delete")
	    public String deleteEmployee(RedirectAttributes redirectAttributes, @RequestParam int no) {
	        try {
	            DeleteResponse response = empservice.deleteEmployeeByEno(no);  // Custom response object

	            if (response.isSuccess()) {
	                redirectAttributes.addFlashAttribute("message", response.getMessage());
	            } else {
	                redirectAttributes.addFlashAttribute("error", response.getMessage());
	            }
	            return "redirect:/report";
	        } catch (Exception e) {
	            e.printStackTrace();
	            redirectAttributes.addFlashAttribute("error", "An error occurred while deleting the employee.");
	            return "redirect:/report";
	        }
	    }
*/


	   
	   /* @GetMapping("/emp_delete")
	    public String deleteEmployee(@RequestParam("no") int eno,RedirectAttributes attrs) {
	        // Logic to delete the employee using eno
	    	System.out.println(eno);
	        
	        String result=empservice.deleteEmployeeByEno(eno);
	        attrs.addFlashAttribute("resultMsg", result);
	        return "redirect:show_employee_report";
	    }*/
	    
//	@GetMapping("/emp_delete1")
//	public   String deleteEmployee1(@RequestParam("eno") int no, RedirectAttributes attrs) {
//		System.out.println(no);
//		String result=empservice.deleteEmployeeByEno(no);
//		
//		//keep results in model attributes
//		attrs.addFlashAttribute("resultMsg", result);
//		return "redirect:show_employee_report";
//		}
	
	
	
	/*
	
	/*@PostMapping("/insert_employee")
	public  String insertEmployee(RedirectAttributes attrs,
			@ModelAttribute("emp")Employee emp) {
		//use service
		String result=service.insertEmployee(emp);
		//add result to model attribute 
	    attrs.addFlashAttribute("resultMsg",result);
		return "redirect:emp_report";
		
	}
	@GetMapping("/insert_employee")
	public  String   showAddEmployeeForm(@ModelAttribute("emp") Employee emp) {
		   //return LNV
		return "add_employee";
	}
	
	
	
	@PostMapping("/edit_employee")
	public  String  editEmployee(RedirectAttributes attrs ,
			                                               @ModelAttribute("emp") Employee emp) {
		//use service
		String result=service.updateEmployee(emp);
		//keep results in model attributes
		attrs.addFlashAttribute("resultMsg", result);
		return "redirect:emp_report";
	}
	
	*/
	}
	

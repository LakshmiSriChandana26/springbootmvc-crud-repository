package com.nt.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/*@Entity
@Table(name="emp")
@Data
public class Employee {
	@Id
	@SequenceGenerator(name="gen1",sequenceName="emp_id_seq",initialValue=1,allocationSize=1)
	@GeneratedValue(generator = "gen1",strategy = GenerationType.SEQUENCE)
	private Integer empno;
	@Column(length=20)
	private  String ename;
	@Column(length=20)
	private  String job;
	private  Float sal;
	private  Integer deptno;
	public String getEmpno() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
*/


@Entity
@Table(name = "emp")
public class Employee {

    @Id
    @SequenceGenerator(
        name = "gen1",
        sequenceName = "emp_id_seq",
        initialValue = 1,
        allocationSize = 1
    )
    @GeneratedValue(generator = "gen1", strategy = GenerationType.SEQUENCE)
   
    private Integer empno;

    @Column(length = 20)
    private String empname;

    @Column(length = 20, nullable = false)
    private String job;

    @Column(nullable = false)
    private Float sal;

    @Column(nullable = false)
    private Integer deptno;

	public Integer getEmpno() {
		return empno;
	}

	public void setEmpno(Integer empno) {
		this.empno = empno;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public Float getSal() {
		return sal;
	}

	public void setSal(Float sal) {
		this.sal = sal;
	}

	public Integer getDeptno() {
		return deptno;
	}

	public void setDeptno(Integer deptno) {
		this.deptno = deptno;
	}

	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", empname=" + empname + ", job=" + job + ", sal=" + sal + ", deptno="
				+ deptno + "]";
	}

	public Employee(Integer empno, String empname, String job, Float sal, Integer deptno) {
		super();
		this.empno = empno;
		this.empname = empname;
		this.job = job;
		this.sal = sal;
		this.deptno = deptno;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}

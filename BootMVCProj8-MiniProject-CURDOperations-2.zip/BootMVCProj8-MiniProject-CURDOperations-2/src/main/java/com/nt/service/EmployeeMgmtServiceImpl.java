/*package com.nt.service;

import java.util.Optional;
import java.util.function.Supplier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.nt.exception.EmployeeNotFoundException;
import com.nt.model.Employee;
import com.nt.repository.IEmployeeRepo;

@Service("empService")
public class EmployeeMgmtServiceImpl  implements IEmployeeMgmtService {
	@Autowired
    private  IEmployeeRepo  empRepo;
	
	@Override
	public Iterable<Employee> getAllEmployees() {
		
		return empRepo.findAll();
	}
	@Override
	public String registerEmployee(Employee emp) {
		return "employee is saved with id value:"+empRepo.save(emp).getEmpno();
	}
	@Override
	public Employee getEmployeeByEno(int eno) {
		return empRepo.findById(eno).orElseThrow(()->new EmployeeNotFoundException("emp not found"));
				
	/*Optional<Employee> opt=empRepo.findById(eno);
		if(opt.isPresent())
			return opt.get();
		else
			throw  new EmployeeNotFoundException("emplolyee with ::"+eno+ " not found ");
	}
	
	@Override
	public String updateEmployee(Employee emp) {
		return  empRepo.save(emp).getEmpno()+" Employee updated";
	}
	
	@Override
	public String deleteEmployeeByEno(int eno) {
		empRepo.deleteById(eno);
		return eno+"  employee number  Employee deleted";
	}

}*/

package com.nt.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nt.exception.EmployeeNotFoundException111;
import com.nt.model.Employee;
import com.nt.repository.IEmployeeRepo;
@Service("empService") // Correctly register the bean with this name
public class EmployeeMgmtServiceImpl implements IEmployeeMgmtService {
    @Autowired
    private IEmployeeRepo empRepo;

    @Override
    public Iterable<Employee> getAllEmployees() {
        return empRepo.findAll();
    }

    @Override
    public String registerEmployee(Employee emp) {
        return "Employee is saved with ID: " + empRepo.save(emp).getEmpno();
    }
    /*@Override
    public Employee getEmployeeByEno(int eno) {
    	Employee emp=empRepo.findById(eno).orElseThrow((new IllegalArgumentException()));
    	return emp;
    }
    */
    @Override
    public Employee getEmployeeByEno(int eno) {
        return empRepo.findById(eno).orElseThrow(
            () -> new EmployeeNotFoundException111("Employee not found with ID: " + eno)
        );
    }

    /*@Override
    public String updateEmployee(Employee emp) {
        return empRepo.save(emp).getEmpno() + " Employee updated";
    }
*/
    @Override
    public String updateEmployee(Employee emp) {
        return "employee is updaed with"+empRepo.save(emp).getEmpno();
    }
    @Override
    public String deleteEmployeeByEno(int eno) {	
        empRepo.deleteById(eno);
        return "Employee with ID: " + eno + " deleted";
    }

    @Override
    public String insertEmployee(Employee emp) {
        return "Employee is saved with ID: " + empRepo.save(emp).getEmpno();
    }
}

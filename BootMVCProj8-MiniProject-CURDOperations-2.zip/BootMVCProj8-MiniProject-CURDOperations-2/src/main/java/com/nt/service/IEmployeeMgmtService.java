package com.nt.service;

import java.util.List;

import com.nt.model.Employee;

/*public interface IEmployeeMgmtService {
	public Iterable<Employee>getAllEmployees();
	public String registerEmployee(Employee emp);
     public  Employee  getEmployeeByEno(int eno);
    public  String    updateEmployee(Employee emp);   
    public  String    deleteEmployeeByEno(int eno);
}

*/
public interface IEmployeeMgmtService {
    
    // Retrieve all employees
    public Iterable<Employee> getAllEmployees();

    // Register a new employee
    public String registerEmployee(Employee emp);

    // edit an employee by their ID (Employee Number)
    public Employee getEmployeeByEno(int eno);

    // Update an existing employee's details
    public String updateEmployee(Employee emp);

    // Delete an employee by their ID (Employee Number)
    public String deleteEmployeeByEno(int eno);
    //insert employee data
	public String insertEmployee(Employee emp);
}
